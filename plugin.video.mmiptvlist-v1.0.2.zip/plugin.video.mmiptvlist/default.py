﻿# -*- coding: utf-8 -*-
import sys
import urllib.request
import re
import xbmcplugin
import xbmcgui
import urllib.parse

HANDLE = int(sys.argv[1])
ARGS = urllib.parse.parse_qs(sys.argv[2][1:])
BASE_URLS = {
    'tv': 'https://raw.githubusercontent.com/mmdigitalworld/MMiptvLIST/main/MMiptvLIST.m3u',
    'CineMM': 'https://raw.githubusercontent.com/mmdigitalworld/MMiptvLIST/main/CineMM.m3u',
    'MMtvCENTER': 'https://raw.githubusercontent.com/mmdigitalworld/MMiptvLIST/main/MMtvCENTER.m3u',
    'MMgamePLAYING': 'https://raw.githubusercontent.com/mmdigitalworld/MMiptvLIST/main/MMgamePLAYING.m3u',
    'video': 'https://raw.githubusercontent.com/mmdigitalworld/MMiptvLIST/main/MM-MUSIC-VIDEOMIXES.m3u',
    'radio': 'https://raw.githubusercontent.com/mmdigitalworld/MMiptvLIST/main/MMwebREDIO.m3u'
}

def get_channels(m3u_url):
    try:
        response = urllib.request.urlopen(m3u_url)
        data = response.read().decode('utf-8', errors='ignore')
        pattern = r'#EXTINF:-?\d+.*?tvg-logo="(.*?)".*?,\s*(.*?)\s*\n(https?://\S+)'
        return re.findall(pattern, data)
    except Exception as e:
        xbmcgui.Dialog().notification('MM IPTV', f'Fehler: {e}', xbmcgui.NOTIFICATION_ERROR)
        return []

def list_main_menu():
    items = [
        ('MMiptvLIST', 'tv'),
        ('CineMM', 'CineMM'),
        ('MMtvCENTER', 'MMtvCENTER'),
        ('MMgamePLAYING', 'MMgamePLAYING'),
        ('MM MUSIC VIDEOMIXES', 'video'),
        ('MMwebREDIO', 'radio')
    ]
    for label, mode in items:
        url = f'{sys.argv[0]}?mode={mode}'
        li = xbmcgui.ListItem(label=label)
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE)

def list_channels(mode):
    channels = get_channels(BASE_URLS[mode])
    for logo, name, url in channels:
        li = xbmcgui.ListItem(label=name)
        li.setProperty('IsPlayable', 'true')
        li.setArt({'thumb': logo, 'icon': logo, 'fanart': logo})
        li.setPath(url)
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(HANDLE)

if __name__ == '__main__':
    mode = ARGS.get('mode', [None])[0]
    if mode in BASE_URLS:
        list_channels(mode)
    else:
        list_main_menu()
